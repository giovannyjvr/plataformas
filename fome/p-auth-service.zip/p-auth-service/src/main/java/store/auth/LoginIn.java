package store.auth;

// usado em AuthResource para login
public interface LoginIn {
    String email();
    String password();
}
